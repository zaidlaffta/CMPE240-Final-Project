//Zaid Laffta
//Comp 240
//Final project

#include "main.h"
#include <stdio.h>
#include "retarget.h"
/* Private includes ----------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;
NAND_HandleTypeDef hnand1;

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_FMC_Init(void);
static void MX_USART1_UART_Init(void);

/* Private user code ---------------------------------------------------------*/

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  printf("Initializing.....\n\n");
  /* MCU Configuration--------------------------------------------------------*/
  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_FMC_Init();
  MX_USART1_UART_Init();
  RetargetInit(&huart1);

  /* Initialize NAND Device ID data structure. */
  NAND_IDTypeDef pNAND_ID;
  pNAND_ID.Device_Id = 1;
  pNAND_ID.Fourth_Id = 0;
  pNAND_ID.Maker_Id = 12;
  pNAND_ID.Third_Id = 0;
  pNAND_ID.Fifth_Id = 0;

  /* Initialize NAND Address data structure. */
  NAND_AddressTypeDef address;
  address.Plane = 0;
  address.Block = 5;
  address.Page = 5;

  /* ======================= NAND FLASH DEVICE READ VALIDATION ========================= */
  /* Read the Device ID from the NAND flash device. */
  if (HAL_NAND_Read_ID(&hnand1, &pNAND_ID) != HAL_OK)
  {
	  return;
  }
  printf("========== NAND Flash Device ID ==========\n");
  printf("DEVICE,DeviceID,0x%x\n", pNAND_ID.Device_Id);
  printf("DEVICE,MakerID,0x%x\n", pNAND_ID.Maker_Id);
  printf("DEVICE,ThirdID,0x%x\n", pNAND_ID.Third_Id);
  printf("DEVICE,FourthID,0x%x\n", pNAND_ID.Fourth_Id);
  printf("DEVICE,FifthID,0x%x\n", pNAND_ID.Fifth_Id);
  printf("===========================================\n");
  printf("Starting in 5 seconds.\n\n\n");
  HAL_Delay(5000);  // 5 seconds wait.

  /* ======================= NAND FLASH INITIAL READ TEST ========================= */
  /* Read a page from the NAND Flash. */
  uint8_t readbuffer[2048];
  if ( HAL_NAND_Read_Page_8b(&hnand1, &address, &readbuffer, 1) != HAL_OK) {
	  printf("Could not Read the page from the NAND Flash device!\n");
	  return;
  }
  /* Print out the page from the NAND Flash. */
  printf("========== NAND Flash Read (Block %x, Page %x) ==========\n", address.Block, address.Page);
  for(int address_idx = 0; address_idx < 2048; ++address_idx) {
	  printf("Read first time,%d,0x%x\n", address_idx, readbuffer[address_idx]);
  }
  printf("===========================================\n");
  int max_cycles = 3000;
  printf("Test Read finished... starting %d cycles write/read operation in 5 seconds...\n\n\n", max_cycles);
  HAL_Delay(5000);  // 5 seconds wait.

  /* ======================= NAND FLASH READ/WRITE STEPS ========================= */
  printf("Setting ECC Disabled for NAND Flash.\Starting new cycle\n");
  if ( HAL_NAND_ECC_Disable(&hnand1) != HAL_OK ) {
	  printf("Could not set ECC Disabled for NAND Flash device!\n");
	  return;
  }
  HAL_Delay(5000);

  printf("Write Cycles begin.\n");
  /* Create the write buffer for HAL_NAND_Write_Page command. */
  uint8_t writebuffer[2048];
  for (int i = 0; i < 2048; i++)
  {
	  writebuffer[i]=0x66;  // 8-bit value in one "location" filled with 0110 0110
  }
  printf("Writing value %x to all positions.\n", writebuffer[0]);

  /* Perform a Write cycles max_cycles times, & on each cycle read back the values. */
  printf("WRITING/READING from Block %x, Page %x for %d CYCLES.\n", address.Block, address.Page, max_cycles);
  for(int cycle = 1; cycle <= max_cycles; ++cycle)
  {
	  printf("------Write cycle %d------\n", cycle);
	  /* Write a page to the NAND flash (1 page length) */
	  //HAL_NAND_Erase_Block(&hnand1, &address);
	  if ( HAL_NAND_Write_Page_8b(&hnand1, &address, &writebuffer,(uint32_t) 1) != HAL_OK) {
		  printf("Could not Write a page to the NAND Flash device!\n");
		  return;
	  }

	  /* Before reading the readbuffer, zero all values in the buffer. */
	  for (int idx = 0; idx < 2048; ++idx) {
		  readbuffer[idx] = 0;
	  }

	  /* Read the page from the NAND flash */
	  if ( HAL_NAND_Read_Page_8b(&hnand1, &address, &readbuffer, 1) != HAL_OK) {
		  printf("Could not Read the page from the NAND Flash device!\n");
		  return;
	  }

	  /* Output all the contents of the read output.*/
	  for(int address_idx = 0; address_idx < 2048; ++address_idx) {
		  printf("Write then Read Cycle,%d,%d,0x%x\n", cycle, address_idx, readbuffer[address_idx]);
	  }
  }
  printf("Execution completed!\n");
  // Use Python to do post-processing via XORing data and such.
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage 
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/* FMC initialization function */
static void MX_FMC_Init(void)
{

  /* USER CODE BEGIN FMC_Init 0 */

  /* USER CODE END FMC_Init 0 */

  FMC_NAND_PCC_TimingTypeDef ComSpaceTiming = {0};
  FMC_NAND_PCC_TimingTypeDef AttSpaceTiming = {0};

  /* USER CODE BEGIN FMC_Init 1 */

  /* USER CODE END FMC_Init 1 */

  /** Perform the NAND1 memory initialization sequence
  */
  hnand1.Instance = FMC_NAND_DEVICE;
  /* hnand1.Init */
  hnand1.Init.NandBank = FMC_NAND_BANK2;
  hnand1.Init.Waitfeature = FMC_NAND_PCC_WAIT_FEATURE_ENABLE;
  hnand1.Init.MemoryDataWidth = FMC_NAND_PCC_MEM_BUS_WIDTH_8;
  hnand1.Init.EccComputation = FMC_NAND_ECC_DISABLE;
  hnand1.Init.ECCPageSize = FMC_NAND_ECC_PAGE_SIZE_256BYTE;
  hnand1.Init.TCLRSetupTime = 500;
  hnand1.Init.TARSetupTime = 500;
  /* hnand1.Config */
  hnand1.Config.PageSize = 2048;
  hnand1.Config.SpareAreaSize = 64;
  hnand1.Config.BlockSize = 64;
  hnand1.Config.BlockNbr = 8;
  hnand1.Config.PlaneNbr = 1;
  hnand1.Config.PlaneSize = 1024;
  hnand1.Config.ExtraCommandEnable = DISABLE;
  /* ComSpaceTiming */
  ComSpaceTiming.SetupTime = 252;
  ComSpaceTiming.WaitSetupTime = 252;
  ComSpaceTiming.HoldSetupTime = 252;
  ComSpaceTiming.HiZSetupTime = 252;
  /* AttSpaceTiming */
  AttSpaceTiming.SetupTime = 252;
  AttSpaceTiming.WaitSetupTime = 252;
  AttSpaceTiming.HoldSetupTime = 252;
  AttSpaceTiming.HiZSetupTime = 252;

  if (HAL_NAND_Init(&hnand1, &ComSpaceTiming, &AttSpaceTiming) != HAL_OK)
  {
    Error_Handler( );
  }

  /* USER CODE BEGIN FMC_Init 2 */

  /* USER CODE END FMC_Init 2 */
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_RESET);

  /*Configure GPIO pin : PG14 */
  GPIO_InitStruct.Pin = GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
